# sohbet-ve-oyun
sizin zamanında çalıntı kod dediğiniz, şu an da clone edip kullandığınız ve benim sildiğim botun dosyaları keyfini çıkarın

madem çalıntı diyorsunuz ya, kendiniz kurarsınız o zaman. çok bildiğinizden dolayı kodlamayı, benden yardım istemesiniz.

ha bu arada botu açmayı başarabilen biri olursa özelden benle iletişime geçsin, direk ekibe alınacak

KESİNLİKLE BENDEN YARDIM İSTEMEYİN DİREK ENGELLERİM BAŞTAN SÖYLÜYORUM.
