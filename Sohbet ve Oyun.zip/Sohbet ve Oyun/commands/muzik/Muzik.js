exports.QUEUE = client.queue;

//exports.GOOGLE_API_KEY = 'AIzaSyCWDx2ab2PFdCZvsv80_kIc_XKlcLViPho';

exports.GOOGLE_API_KEY = 'AIzaSyBI-kdmHoshPZ9bkxsfIF_8mpivrhCVr3k';